package org.iesbelen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebMvcJdbcVentasApplicationTests {

	@Test
	void contextLoads() {
	}

}
